--------------[ Club Pala ]-------------
<#> MC Extremo Vanilla 1.0 <#>
-------------------------------------------
* Date:	03/10/23

# Requirements
    * Server
    * Version: 1.16+

# Config
    * In server.proterties: function-permission-level = 4